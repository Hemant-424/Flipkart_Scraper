import scrapy
from ..items import FlipkartScrapItem


class FlipSpider(scrapy.Spider):
    name = 'FlipScraper'
    page_number = 2
    start_urls = [
        "https://www.flipkart.com/womens-footwear/pr?sid=osp%2Ciko&otracker=nmenu_sub_Women_0_Footwear"
    ]

    def parse(self, response):

        item = FlipkartScrapItem()  # creating an instanse for FlipkartScrapItem

        container = response.css('._13oc-S > div')  # building container, which contains all the below details.

        # iterating over container
        for data in container:

            name = data.css('.IRpwTa::text').extract()  # etracting name of products
            brand = data.css('._2WkVRV::text').extract()  # extracting brand of products
            original_price = data.css('._3I9_wc::text').extract()  # extracting original_price of products
            sale_price = data.css('._30jeq3::text').extract()  # extracting sale_price of products
            image_url = data.css('a._2UzuFa::attr(href)').extract()[0]
            product_page_url = data.css('a._2UzuFa::attr(href)').extract()[0]  # extracting product_page_url of products
            offer = data.css('._3Ay6Sb span::text').extract()  # extracting offer of products

            # storing the extracted values in the FlipkartScrapItem instanse

            item['name'] = name
            item['brand'] = brand
            item['original_price'] = original_price
            item['sale_price'] = sale_price
            item['offer'] = offer
            item['image_url'] = "https://www.flipkart.com" +str(image_url)
            item['product_page_url'] = "https://www.flipkart.com" + str(product_page_url)

            yield item

            # making loops for next_page

            next_page = 'https://www.flipkart.com/womens-footwear/pr?sid=osp%2Ciko&otracker=nmenu_sub_Women_0_Footwear&page=+' + str(FlipSpider.page_number)
            if FlipSpider.page_number <= 25:
                FlipSpider.page_number += 1
                yield response.follow(next_page, callback=self.parse)
