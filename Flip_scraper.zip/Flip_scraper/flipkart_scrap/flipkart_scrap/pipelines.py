# Define your item pipelines here
#
# Dont forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from itemadapter import ItemAdapter

from pymongo import MongoClient

class FlipkartScrapPipeline():

    def __init__(self):
        self.conn = MongoClient(
            'mongodb+srv://HemantSingh:Hemant789@cluster0.qtpy3.mongodb.net/HemantSingh?retryWrites=true&w=majority')
        self.db = self.conn.get_database('HemantSingh')
        self.record = self.db.Flipkart

    def process_item(self, item, spider):
        self.record.insert_many(item)
        return item
